#include "dragon.h"

Dragon::Dragon(shared_ptr <Enemy> e) : EnemyDecorator{e}{}



