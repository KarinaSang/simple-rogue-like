#include "treasure.h"

Treasure::Treasure(int value, bool collectable) : value{value}, collectable{collectable} {}

