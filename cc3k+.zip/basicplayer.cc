#include "basicplayer.h"

BasicPlayer::BasicPlayer(int hp, int atk, int def, string race): Player{hp, atk, def, race} {}

