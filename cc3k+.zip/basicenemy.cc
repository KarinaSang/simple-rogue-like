#include "basicenemy.h"

BasicEnemy::BasicEnemy(int hp, int atk, int def, string race, char display, int value):
	Enemy{hp, atk, def, race, display, value} {}
