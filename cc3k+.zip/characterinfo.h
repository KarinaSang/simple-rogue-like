#ifndef CHARACTERINFO_H
#define CHARACTERINFO_H

struct CharacterInfo{
	int hp;
	int atk;
	int def;
};

#endif
