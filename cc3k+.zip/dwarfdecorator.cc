#include "dwarfdecorator.h"

void DwarfDecorator::addGold(int n){
	PlayerDecorator::addGold(n*2);
}
