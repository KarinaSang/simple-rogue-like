#include "orcdecorator.h"

void OrcDecorator::addGold(int n){
	PlayerDecorator::addGold(n*0.5);
}
