#include "merchant.h"

Merchant::Merchant (shared_ptr <Enemy> e): EnemyDecorator{e} {
}

